--- Getter to check the neon colour of a vehicle. This native is the server side getter of [GET_VEHICLE_NEON_LIGHTS_COLOUR](#\_0x7619EEE8C886757F).
-- @param vehicle The vehicle to check.
-- @param red Pointer to an integer where the red component of the neon color will be stored.
-- @param green Pointer to an integer where the green component of the neon color will be stored.
-- @param blue Pointer to an integer where the blue component of the neon color will be stored.
-- @return None. The neon color values are retrieved and stored in the `red`, `green`, and `blue` pointers. Make sure to store the returned values in variables for further use.
function Global.GetVehicleNeonColour(vehicle)
	return _in(0xd9319dcb, vehicle, _i, _i, _i)
end
