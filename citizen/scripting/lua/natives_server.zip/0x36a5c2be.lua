--- IS_PED_IN_ANY_VEHICLE
-- @param ped the ped id
-- @return Returns `true` if the specified `ped` is in any vehicle
function Global.IsPedInAnyVehicle(ped)
	return _in(0x3b0171ee, ped, _r)
end
