--- IS_PED_ON_MOUNT
-- @param ped the ped id
-- @return Returns `true` if the specified `ped` is on a mount.
function Global.IsPedOnMount(ped)
	return _in(0x43103006, ped, _r)
end
