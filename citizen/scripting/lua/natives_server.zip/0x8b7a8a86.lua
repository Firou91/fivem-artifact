--- Scope exit for profiler.
function Global.ProfilerExitScope()
	return _in(0xb39ca35c)
end
