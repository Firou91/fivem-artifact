--- **Note**: This native is deprecated, please use [`GET_HELI_REAR_ROTOR_HEALTH`](#\_0x33EE6E2B) instead.
-- @param vehicle The target vehicle.
-- @return Return the health of the rear rotor of the helicopter, not the tail rotor.
function Global.GetHeliTailRotorHealth(vehicle)
	return _in(0xa41bc13d, vehicle, _rf)
end
