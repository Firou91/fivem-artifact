--- Gets the trains desired speed.
-- @param train The train handle
-- @return The desired cruise speed of the train. Not the speed the train is currently traveling at
function Global.GetTrainCruiseSpeed(train)
	return _in(0xa4921ef5, train, _rf)
end
