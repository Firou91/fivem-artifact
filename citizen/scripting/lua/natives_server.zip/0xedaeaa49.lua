--- GET_HELI_YAW_CONTROL
-- @param heli The helicopter to check.
-- @return Returns a value the yaw control of the helicopter. The value ranges from `-1.0` (yaw left) to `1.0` (yaw right), with `0.0` meaning no yaw input.
function Global.GetHeliYawControl(heli)
	return _in(0x8fdc0768, heli, _rf)
end
