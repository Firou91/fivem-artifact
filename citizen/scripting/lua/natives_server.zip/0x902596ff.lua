--- Depending on your use case you may need to use `add_acl resource.<your_resource_name> command.<command_name> allow` to use this native in your resource.
function Global.ExecuteCommand(commandString)
	return _in(0x561c060b, _ts(commandString))
end
