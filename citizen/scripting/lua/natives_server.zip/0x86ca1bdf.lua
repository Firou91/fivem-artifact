--- GET_MOUNT
-- @param ped the ped id
-- @return Returns the entity the `ped` is currently on, or `0` if they're not on a mount.
function Global.GetMount(ped)
	return _in(0xdd31ec4e, ped, _ri)
end
