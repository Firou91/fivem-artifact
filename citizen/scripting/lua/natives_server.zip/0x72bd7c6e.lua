--- Adds a listener for Console Variable changes.
-- The function called expects to match the following signature:
-- ```ts
-- function ConVarChangeListener(conVarName: string, reserved: any);
-- ```
-- *   **conVarName**: The ConVar that changed.
-- *   **reserved**: Currently unused.
-- @param conVarFilter The Console Variable to listen for, this can be a pattern like "test:\*", or null for any
-- @param handler The handler function.
-- @return A cookie to remove the change handler.
function Global.AddConvarChangeListener(conVarFilter, handler)
	return _in(0xab7f7241, _ts(conVarFilter), _mfr(handler), _ri)
end
