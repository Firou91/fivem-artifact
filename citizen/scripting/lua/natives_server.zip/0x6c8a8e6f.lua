--- Gets the direction the train is facing
-- @param train The train handle
-- @return True if the train is moving forward on the track, False otherwise
function Global.GetTrainDirection(train)
	return _in(0x8daf79b6, train, _r)
end
