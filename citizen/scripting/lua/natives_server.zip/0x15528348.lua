--- GET_ENTITY_COLLISION_DISABLED
-- @param entity The target entity.
-- @return Returns whether or not entity collisions are disabled.
function Global.GetEntityCollisionDisabled(entity)
	return _in(0xe8c0c629, entity, _r)
end
