--- GET_HELI_MAIN_ROTOR_HEALTH
-- @param vehicle The target vehicle.
-- @return See the client-side [GET_HELI_MAIN_ROTOR_HEALTH](#\_0xE4CB7541F413D2C5) for the return value.
function Global.GetHeliMainRotorHealth(vehicle)
	return _in(0xf01e2aab, vehicle, _rf)
end
