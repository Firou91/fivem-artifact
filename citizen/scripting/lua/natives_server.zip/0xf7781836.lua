--- GET_STATE_BAG_KEYS
-- @param bagName The name of the bag.
-- @return Returns an array containing all keys for which the state bag has associated values.
function Global.GetStateBagKeys(bagName)
	return _in(0x78d864c7, _ts(bagName), _ro)
end
