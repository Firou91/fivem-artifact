--- Returns the open position of the specified door on the target vehicle.
-- @param vehicle The target vehicle.
-- @param doorIndex Index of door to check (0-6).
-- @return A number from 0 to 7.
function Global.GetVehicleDoorStatus(vehicle, doorIndex)
	return _in(0x6e35c49c, vehicle, doorIndex, _ri)
end
