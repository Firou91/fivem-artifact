--- IS_TRAIN_CABOOSE
-- @param train The train handle
-- @return Returns true if the train is the caboose of the chain.
function Global.IsTrainCaboose(train)
	return _in(0xfa9336e5, train, _r)
end
