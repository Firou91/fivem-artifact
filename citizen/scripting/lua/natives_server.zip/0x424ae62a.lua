--- GET_INVOKING_RESOURCE
function Global.GetInvokingResource()
	return _in(0x4d52fe5b, _s)
end
