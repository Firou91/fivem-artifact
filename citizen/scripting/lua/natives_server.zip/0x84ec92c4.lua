--- IS_PED_IN_VEHICLE
-- @param ped the ped id
-- @param vehicle the vehicle id
-- @return Returns `true` if the specified `ped` is in the specified `vehicle`
function Global.IsPedInVehicle(ped, vehicle)
	return _in(0x7da6bc83, ped, vehicle, _r)
end
