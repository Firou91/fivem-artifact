--- p4/p5: Unusued in TU27
-- ### Ragdoll Types
-- **0**: CTaskNMRelax
-- **1**: CTaskNMScriptControl: Hardcoded not to work in networked environments.
-- **Else**: CTaskNMBalance
-- @param ped The ped to ragdoll.
-- @param minTime Time(ms) Ped is in ragdoll mode; only applies to ragdoll types 0 and not 1.
-- @param bAbortIfInjured unused
-- @param bAbortIfDead unused
function Global.SetPedToRagdoll(ped, minTime, maxTime, ragdollType, bAbortIfInjured, bAbortIfDead, bForceScriptControl)
	return _in(0x83cb5052, ped, minTime, maxTime, ragdollType, bAbortIfInjured, bAbortIfDead, bForceScriptControl)
end
