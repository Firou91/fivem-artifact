--- Sets the culling radius for the specified player.
-- Set to `0.0` to reset.
-- **WARNING**: Culling natives are deprecated and have known, [unfixable issues](https://forum.cfx.re/t/issue-with-culling-radius-and-server-side-entities/4900677/4)
-- @param playerSrc The player to set the culling radius for.
-- @param radius The radius.
function Global.SetPlayerCullingRadius(playerSrc, radius)
	return _in(0x8a2fbad4, _ts(playerSrc), radius)
end
