--- GET_THRUSTER_SIDE_RCS_THROTTLE
-- @param jetpack The jetpack to check.
-- @return Returns a value representing the side RCS (Reaction Control System) throttle of the jetpack. The values range from `0.0` (no throttle) to `1.0` (full throttle).
function Global.GetThrusterSideRcsThrottle(jetpack)
	return _in(0x1c939e87, jetpack, _rf)
end
