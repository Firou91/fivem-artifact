--- IS_PED_USING_ACTION_MODE
-- @param ped The target ped.
-- @return Whether or not the ped is using action mode.
function Global.IsPedUsingActionMode(ped)
	return _in(0x5ae7eda2, ped, _r)
end
