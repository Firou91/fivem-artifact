--- Deletes the specified entity.
-- **NOTE**: For trains this will only work if called on the train engine, it will not work on its carriages.
-- @param entity The entity to delete.
function Global.DeleteEntity(entity)
	return _in(0xfaa3d236, entity)
end
