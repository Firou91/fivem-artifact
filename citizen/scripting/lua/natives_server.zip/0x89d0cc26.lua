--- GET_ENTITY_REMOTE_SYNCED_SCENES_ALLOWED
-- @param entity The entity to get the flag for.
-- @return Returns if the entity is allowed to participate in network-synchronized scenes initiated by clients that do not own the entity.
function Global.GetEntityRemoteSyncedScenesAllowed(entity)
	return _in(0x91b38fb6, entity, _r)
end
