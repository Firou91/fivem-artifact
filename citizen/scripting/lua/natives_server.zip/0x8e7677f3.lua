--- FIND_KVP
-- @param handle The KVP find handle returned from [START_FIND_KVP](#\_0xDD379006)
-- @return None.
function Global.FindKvp(handle)
	return _in(0xbd7bebc5, handle, _s)
end
