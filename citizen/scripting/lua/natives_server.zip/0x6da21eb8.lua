--- IS_PED_STRAFING
-- @param ped The target ped.
-- @return Whether or not the ped is strafing.
function Global.IsPedStrafing(ped)
	return _in(0xefeed13c, ped, _r)
end
