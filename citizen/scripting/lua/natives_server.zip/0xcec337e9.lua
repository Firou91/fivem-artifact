--- GET_TRAIN_TRACK_INDEX
-- @param train The train handle
-- @return The track index the train is currently on.
function Global.GetTrainTrackIndex(train)
	return _in(0x9aa339d, train, _ri)
end
