--- GET_SEAT_PED_IS_USING
-- @param ped the ped id
-- @return Returns the seat index for specified `ped`, if the ped is not sitting in a vehicle it will return -3.
function Global.GetSeatPedIsUsing(ped)
	return _in(0x57b78c17, ped, _ri)
end
