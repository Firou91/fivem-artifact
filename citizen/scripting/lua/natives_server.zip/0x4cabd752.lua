--- GET_TRAIN_FORWARD_CARRIAGE
-- @param train The train handle
-- @return The handle of the carriage in front of this train in the chain. Otherwise returns 0 if the train has no carriage in front of it
function Global.GetTrainForwardCarriage(train)
	return _in(0x24dc88d9, train, _ri)
end
