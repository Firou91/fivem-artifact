--- GET_HELI_THROTTLE_CONTROL
-- @param heli The helicopter to check.
-- @return Returns a value representing the throttle control of the helicopter. The value ranges from `0.0` (no throttle) to `2.0` (full throttle).
function Global.GetHeliThrottleControl(heli)
	return _in(0x8e86238d, heli, _rf)
end
