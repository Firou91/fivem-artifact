--- GET_TRAIN_BACKWARD_CARRIAGE
-- @param train The train handle
-- @return The handle of the carriage behind this train in the chain. Otherwise returns 0 if the train is the caboose of the chain.
function Global.GetTrainBackwardCarriage(train)
	return _in(0x456e34a, train, _ri)
end
